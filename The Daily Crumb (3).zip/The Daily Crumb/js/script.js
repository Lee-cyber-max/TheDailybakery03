function showTodayPrecise() {
  const now = new Date();
  const options = {
    timeZone: 'Africa/Johannesburg',
    weekday: 'long',
    year: 'numeric',
    month: 'long',
    day: 'numeric',
    hour: '2-digit',
    minute: '2-digit',
    second: '2-digit',
    hour12: true
  };
  const el = document.getElementById("liveTime");
  if (el) {
    el.textContent = "Today: " + now.toLocaleString('en-ZA', options) + " SAST";
  }
  const yearEl = document.getElementById("year");
  if (yearEl) yearEl.textContent = now.getFullYear();
}
setInterval(showTodayPrecise, 1000);
showTodayPrecise();

document.addEventListener("DOMContentLoaded", function () {

    console.log("The Daily Crumb website has loaded successfully.");

    
    const enquiryForm = document.querySelector("form");

    if (enquiryForm) {

        enquiryForm.addEventListener("submit", function (event) {

            event.preventDefault();

            const name = document.querySelector("#name");

            if (name && name.value.trim() === "") {

                alert("Please enter your full name.");

                name.focus();

                return;
            }

            alert(
                "Thank you for your enquiry, " +
                name.value +
                "! We will get back to you soon."
            );

            enquiryForm.reset();

        });

    }

});
