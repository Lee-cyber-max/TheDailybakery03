# The Daily Crumb Bakery Website - WEDE5020 Part 3

## Project Overview
A responsive bakery website for a small business in Pretoria. Built with HTML, CSS, JavaScript. Features enquiry form that sends confirmation to customer.

## Features (Part 3)
- Responsive design (mobile + desktop)
- Interactive enquiry form with JS validation
- Customer auto-response on form submit
- SEO optimized (meta tags, alt text, sitemap)
- Leaflet map integration

## How to Run
1. Clone repo: git clone https://github.com/YOURUSERNAME/bakery-site.git
2. Open index.html in browser

## File Structure
/css/style.css - All styling
/js/script.js - Form validation
index.html, about.html, enquiry.html, contact.html

## Changelog

- Fixed CSS not linking - added correct href="css/style.css"
- Fixed logo size to 60px to prevent layout break
- Fixed enquiry form dropdown being cut off - added z-index and width 100%
- Made site responsive with @media (max-width: 768px) - form stacks on mobile
- Added JS customer response box that shows name, enquiry type, email after submit
- Added SEO: title tags, meta description, alt text for all images, sitemap.xml
- Added GitHub descriptive commits



## References

- W3Schools (2024) HTML Forms. Available at: https://www.w3schools.com/html/html_forms.asp
- MDN Web Docs (2024) CSS Flexbox. Available at: https://developer.mozilla.org/en-US/docs/Web/CSS/CSS_Flexible_Box_Layout
- EmailJS (2024) EmailJS Documentation. Available at: https://www.emailjs.com/docs/
- Leaflet (2024) Leaflet Maps. Available at: https://leafletjs.com/

## Student
Name: [Lethabo Zulu]
Student No: [ST 10524406]
Module: WEDE5020 Term 2 GR02